package com.gplabs.booklistapp;

import java.util.ArrayList;

/**
 * Created by pedronice on 29/12/16.
 */

public class Book {
    private String mTitulo;
    private String mAuthor;

    public Book(String titulo, String author) {
        this.mTitulo = titulo;
        this.mAuthor = author;
    }

    public String getTitulo() {
        return mTitulo;
    }

    public String getAuthor() {
        return mAuthor;
    }
}
