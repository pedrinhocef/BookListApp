package com.gplabs.booklistapp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private String search = "android";
    private StringBuilder myquery = new StringBuilder();
    private String BOOK_REQUEST_URL = " https://www.googleapis.com/books/v1/volumes?q=" + search + "&maxResults=30";
    private ListView mListView;
    private TextView mEmptyText;
    private BookAdapter mAdapter;



    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                Log.e("hi search", "the final Text of the search is " + search);
                myquery.append(searchView.getQuery().toString().trim());
                search = searchView.getQuery().toString().trim();
                Toast.makeText(MainActivity.this, "Buscando por " + search, Toast.LENGTH_SHORT).show();

                isNetworkAvailable(MainActivity.this);
                if (isNetworkAvailable(MainActivity.this)) {
                    queryApi();
                    return true;
                } else {
                    mAdapter.clear();
                    mEmptyText.setText(getResources().getString(R.string.sem_conexao));
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Log.e("hi search", "the current Text of the search is " + search);
                myquery.append(searchView.getQuery().toString().trim());
                search = searchView.getQuery().toString().trim();

                return false;
            }

        });

        return true;
    }

    private void queryApi() {

        Log.e("hi search", "the final Result of the  search issssssssss " + search);
        BOOK_REQUEST_URL = "https://www.googleapis.com/books/v1/volumes?q=" + search + "&maxResults=30";

        bookAsyncTask task = new bookAsyncTask();
        task.execute(BOOK_REQUEST_URL);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mListView = (ListView) findViewById(R.id.list_view);
        mAdapter = new BookAdapter(this, new ArrayList<Book>());
        mListView.setAdapter(mAdapter);

        mEmptyText = (TextView) findViewById(R.id.empty);
        mListView.setEmptyView(mEmptyText);

        isNetworkAvailable(MainActivity.this);

        if (isNetworkAvailable(MainActivity.this)) {
            Log.e(LOG_TAG, "Conectado: onCreate");
            bookAsyncTask task = new bookAsyncTask();
            task.execute(BOOK_REQUEST_URL);

        } else {
            Log.e(LOG_TAG, "Desconectado: onCreate");
            mEmptyText.setText(getResources().getString(R.string.sem_conexao));

        }

    }

    public class bookAsyncTask extends AsyncTask<String, Void, List<Book>> {

        @Override
        protected List<Book> doInBackground(String... urls) {
            // create URL object
            URL url = createUrl(urls[0]);

            // perform HTTP request to the URL and receive a JSON response back
            String jsonResponse = "";
            try {
                jsonResponse = makeHttpRequest(url);
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error....", e);
            }

            List<Book> bookList = extractFeatureFromJson(jsonResponse);
            return bookList;
        }

        @Override
        protected void onPostExecute(List<Book> bookList) {

            View loadingIndicator = findViewById(R.id.loading_indicator);
            loadingIndicator.setVisibility(View.GONE);

            mAdapter.clear();

            if (bookList != null && !bookList.isEmpty()) {
                mAdapter.addAll(bookList);
                mListView.setEmptyView(mEmptyText);
                mEmptyText.setText(getResources().getString(R.string.empty));
            }

            mAdapter.notifyDataSetChanged();
        }


        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e(LOG_TAG, "Error with creating URL", exception);
                return null;
            }
            return url;
        }

        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";

            //IF the URL is NULL, then return early
            if (url == null) {
                return jsonResponse;
            }
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000 /*milliseconds*/);
                urlConnection.setConnectTimeout(15000/*milliseconds*/);
                urlConnection.connect();

                //if the request was successful(response code 200)
                //then read the input stream and parse the response.
                if (urlConnection.getResponseCode() == 200) {
                    inputStream = urlConnection.getInputStream();
                    jsonResponse = readFromStream(inputStream);
                }
            } catch (IOException e) {
                // TODO: Handle the exception
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    //function must handle java.io.IOException here
                    inputStream.close();
                }
            }
            return jsonResponse;
        }

        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }

        private ArrayList<Book> extractFeatureFromJson(String bookJSON) {
            //if the JSON string is empty or null, then return early
            if (TextUtils.isEmpty(bookJSON)) {
                return null;
            }
            ArrayList<Book> arrayListBook = new ArrayList<>();

            try {


                JSONObject baseJsonResponse = new JSONObject(bookJSON);
                JSONArray itemsArray = baseJsonResponse.getJSONArray("items");

                if (itemsArray.length() > 0) {
                    for (int i = 0; i < itemsArray.length(); i++) {
                        //Extract out the first Volume info (which is an book)
                        JSONObject item = itemsArray.getJSONObject(i);
                        JSONObject volumeInfo = item.getJSONObject("volumeInfo");

                        //Extract out the title and author book values
                        String titulo = volumeInfo.optString("title");
                        String autor = volumeInfo.optString("authors");

                        Book book = new Book(titulo, autor);
                        arrayListBook.add(book);

                    }
                    return arrayListBook;
                }
            } catch (JSONException e) {
                Log.e(LOG_TAG, "Problem parsing the book JSON results", e);

            }
            return null;
        }

    }


    public static boolean isNetworkAvailable(Context context) {
        try {
            ConnectivityManager connectivity = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);

            if (connectivity == null) {
                return false;
            } else {
                NetworkInfo[] info = connectivity.getAllNetworkInfo();
                if (info != null) {
                    for (int i = 0; i < info.length; i++) {
                        if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                            return true;
                        }
                    }
                }
            }
        } catch (SecurityException e) {
            Log.e(LOG_TAG, "Problem status network info", e);
        }

        return false;
    }
}


